'''
binlog2sql:
Parse MySQL binlog to SQL you want.
'''

from .binlog2sql import Binlog2sql
