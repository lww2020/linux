# MySQL Optimal Configuration File

This configration file opts for MySQL 5.6 and 5.7.
If you have any problem, dont hesitate to concact me.
Let us make an optimal MySQL configuration file template for product enviroment.

I assume the MySQL Server as followings. You should tune the variables according to your server. 

* 32 CPU core
* 256G Memory
* SSD storage with 20000 IOPS in 16K page size 

  